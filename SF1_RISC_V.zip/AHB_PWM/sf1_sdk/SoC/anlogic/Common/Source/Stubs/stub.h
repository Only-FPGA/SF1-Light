
static inline int _stub(int err)
{
  return -1;
}
