/*
 * Inverse solution algorithm.c
 *
 *  Created on: 2022年10月26日
 *      Author: 86188
 */
#include "Inverse solution algorithm.h"
#include "nuclei_libopt.h"
#include "pwm.h"
#include "math.h"



float fast_atan_table[257] =
{
    0.000000e+00, 3.921549e-03, 7.842976e-03, 1.176416e-02,
    1.568499e-02, 1.960533e-02, 2.352507e-02, 2.744409e-02,
    3.136226e-02, 3.527947e-02, 3.919560e-02, 4.311053e-02,
    4.702413e-02, 5.093629e-02, 5.484690e-02, 5.875582e-02,
    6.266295e-02, 6.656816e-02, 7.047134e-02, 7.437238e-02,
    7.827114e-02, 8.216752e-02, 8.606141e-02, 8.995267e-02,
    9.384121e-02, 9.772691e-02, 1.016096e-01, 1.054893e-01,
    1.093658e-01, 1.132390e-01, 1.171087e-01, 1.209750e-01,
    1.248376e-01, 1.286965e-01, 1.325515e-01, 1.364026e-01,
    1.402496e-01, 1.440924e-01, 1.479310e-01, 1.517652e-01,
    1.555948e-01, 1.594199e-01, 1.632403e-01, 1.670559e-01,
    1.708665e-01, 1.746722e-01, 1.784728e-01, 1.822681e-01,
    1.860582e-01, 1.898428e-01, 1.936220e-01, 1.973956e-01,
    2.011634e-01, 2.049255e-01, 2.086818e-01, 2.124320e-01,
    2.161762e-01, 2.199143e-01, 2.236461e-01, 2.273716e-01,
    2.310907e-01, 2.348033e-01, 2.385093e-01, 2.422086e-01,
    2.459012e-01, 2.495869e-01, 2.532658e-01, 2.569376e-01,
    2.606024e-01, 2.642600e-01, 2.679104e-01, 2.715535e-01,
    2.751892e-01, 2.788175e-01, 2.824383e-01, 2.860514e-01,
    2.896569e-01, 2.932547e-01, 2.968447e-01, 3.004268e-01,
    3.040009e-01, 3.075671e-01, 3.111252e-01, 3.146752e-01,
    3.182170e-01, 3.217506e-01, 3.252758e-01, 3.287927e-01,
    3.323012e-01, 3.358012e-01, 3.392926e-01, 3.427755e-01,
    3.462497e-01, 3.497153e-01, 3.531721e-01, 3.566201e-01,
    3.600593e-01, 3.634896e-01, 3.669110e-01, 3.703234e-01,
    3.737268e-01, 3.771211e-01, 3.805064e-01, 3.838825e-01,
    3.872494e-01, 3.906070e-01, 3.939555e-01, 3.972946e-01,
    4.006244e-01, 4.039448e-01, 4.072558e-01, 4.105574e-01,
    4.138496e-01, 4.171322e-01, 4.204054e-01, 4.236689e-01,
    4.269229e-01, 4.301673e-01, 4.334021e-01, 4.366272e-01,
    4.398426e-01, 4.430483e-01, 4.462443e-01, 4.494306e-01,
    4.526070e-01, 4.557738e-01, 4.589307e-01, 4.620778e-01,
    4.652150e-01, 4.683424e-01, 4.714600e-01, 4.745676e-01,
    4.776654e-01, 4.807532e-01, 4.838312e-01, 4.868992e-01,
    4.899573e-01, 4.930055e-01, 4.960437e-01, 4.990719e-01,
    5.020902e-01, 5.050985e-01, 5.080968e-01, 5.110852e-01,
    5.140636e-01, 5.170320e-01, 5.199904e-01, 5.229388e-01,
    5.258772e-01, 5.288056e-01, 5.317241e-01, 5.346325e-01,
    5.375310e-01, 5.404195e-01, 5.432980e-01, 5.461666e-01,
    5.490251e-01, 5.518738e-01, 5.547124e-01, 5.575411e-01,
    5.603599e-01, 5.631687e-01, 5.659676e-01, 5.687566e-01,
    5.715357e-01, 5.743048e-01, 5.770641e-01, 5.798135e-01,
    5.825531e-01, 5.852828e-01, 5.880026e-01, 5.907126e-01,
    5.934128e-01, 5.961032e-01, 5.987839e-01, 6.014547e-01,
    6.041158e-01, 6.067672e-01, 6.094088e-01, 6.120407e-01,
    6.146630e-01, 6.172755e-01, 6.198784e-01, 6.224717e-01,
    6.250554e-01, 6.276294e-01, 6.301939e-01, 6.327488e-01,
    6.352942e-01, 6.378301e-01, 6.403565e-01, 6.428734e-01,
    6.453808e-01, 6.478788e-01, 6.503674e-01, 6.528466e-01,
    6.553165e-01, 6.577770e-01, 6.602282e-01, 6.626701e-01,
    6.651027e-01, 6.675261e-01, 6.699402e-01, 6.723452e-01,
    6.747409e-01, 6.771276e-01, 6.795051e-01, 6.818735e-01,
    6.842328e-01, 6.865831e-01, 6.889244e-01, 6.912567e-01,
    6.935800e-01, 6.958943e-01, 6.981998e-01, 7.004964e-01,
    7.027841e-01, 7.050630e-01, 7.073330e-01, 7.095943e-01,
    7.118469e-01, 7.140907e-01, 7.163258e-01, 7.185523e-01,
    7.207701e-01, 7.229794e-01, 7.251800e-01, 7.273721e-01,
    7.295557e-01, 7.317307e-01, 7.338974e-01, 7.360555e-01,
    7.382053e-01, 7.403467e-01, 7.424797e-01, 7.446045e-01,
    7.467209e-01, 7.488291e-01, 7.509291e-01, 7.530208e-01,
    7.551044e-01, 7.571798e-01, 7.592472e-01, 7.613064e-01,
    7.633576e-01, 7.654008e-01, 7.674360e-01, 7.694633e-01,
    7.714826e-01, 7.734940e-01, 7.754975e-01, 7.774932e-01,
    7.794811e-01, 7.814612e-01, 7.834335e-01, 7.853983e-01,
    7.853983e-01
};




float fac(float n){
    float f=0;
    if(n == 1 || n==0)
        f =1;
    else
        f = fac(n-1)*n;

    return f;
}
//一个指数函数(次方)

float kvat(float n,float ci){
    float chengf=1;
    int i;
	    for (i=1; i<=ci; i++) {
            chengf = chengf*n;
        }
    return chengf;
}
//泰勒计算sin

float sinus(float x)
{
    int z =-1;
    int j =1;
    float sin= x;
    for (j =3;fabs( kvat(x,j)/fac(j) )>0.00001 ; j+=2) {

        sin =sin + z*(kvat(x,j)/fac(j));
        z = -z;
    }
    return sin;
}

//泰勒计算cos
float fcos(float x)
{
    float temp=0.0,t=5;
    int i=0;
    while(x>=2*PI) x=x-2*PI;
    while(t>=0.00001)
    {
        t=(kvat(x,2*i))/fac(2*i);
        temp+=kvat(-1,i)*t;
        i++;

    }
    return temp;
}


//四舍五入整数化

int cel(float x)
{
    int a;
    if(x>0)
        x= x+0.5;
    else {
        x= x -0.5;
    }
    a = x;
    return a;
}





//泰勒计算acos
float my_acos(float x)
{
    unsigned char i;
    float ans = x,t1 = 1,t2 = x;x *= x;
    for(i = 3;i < 51;i += 2)
    {
        t1 *= (float)(i - 2) / (float)(i - 1);
        t2 *= x;
        ans += (t1 * t2 / (float)i);
    }
    return ans = 1.5708 - ans;
}
//计算asin

float my_asin(float in)
{
   float a = PI/2 - my_acos(in);
   return a;
}
//绝对值
float my_abs(float f)
{
    if (f >= 0.0f)
    {
        return f;
    }

    return -f;
}

//半圆法计算atan
float fast_atan2(float y, float x)
{
    float x_abs, y_abs, z;
    float alpha, angle, base_angle;
    int index;

    /* don't divide by zero! */
    if ((y == 0.0f) || (x == 0.0f))//if ((y == 0.0f) && (x == 0.0f))
        angle = 1.5707963705;
    else
    {
        /* normalize to +/- 45 degree range */
        y_abs = my_abs(y);
        x_abs = my_abs(x);
        //z = (y_abs < x_abs ? y_abs / x_abs : x_abs / y_abs);
        if (y_abs < x_abs)
            z = y_abs / x_abs;
        else
            z = x_abs / y_abs;
        /* when ratio approaches the table resolution, the angle is */
        /*      best approximated with the argument itself...       */
        if (z < TAN_MAP_RES)
            base_angle = z;
        else
        {
            /* find index and interpolation value */
            alpha = z * (float) TAN_MAP_SIZE - .5f;
            index = (int) alpha;
            alpha -= (float) index;
            /* determine base angle based on quadrant and */
            /* add or subtract table value from base angle based on quadrant */
            base_angle = fast_atan_table[index];
            base_angle += (fast_atan_table[index + 1] - fast_atan_table[index]) * alpha;
        }

        if (x_abs > y_abs)
        {        /* -45 -> 45 or 135 -> 225 */
            if (x >= 0.0f)
            {           /* -45 -> 45 */
                if (y >= 0.0f)
                    angle = base_angle;   /* 0 -> 45, angle OK */
                else
                    angle = -base_angle;  /* -45 -> 0, angle = -angle */
            }
            else
            {                  /* 135 -> 180 or 180 -> -135 */
                angle = 3.14159265358979323846;

                if (y >= 0.0f)
                    angle -= base_angle;  /* 135 -> 180, angle = 180 - angle */
                else
                    angle = base_angle - angle;   /* 180 -> -135, angle = angle - 180 */
            }
        }
        else
        {                    /* 45 -> 135 or -135 -> -45 */
            if (y >= 0.0f)
            {           /* 45 -> 135 */
                angle = 1.57079632679489661923;

                if (x >= 0.0f)
                    angle -= base_angle;  /* 45 -> 90, angle = 90 - angle */
                else
                    angle += base_angle;  /* 90 -> 135, angle = 90 + angle */
            }
            else
            {                  /* -135 -> -45 */
                angle = -1.57079632679489661923;

                if (x >= 0.0f)
                    angle += base_angle;  /* -90 -> -45, angle = -90 + angle */
                else
                    angle -= base_angle;  /* -135 -> -90, angle = -90 - angle */
            }
        }
    }
#ifdef ZERO_TO_TWOPI
    if (angle < 0)
        return (angle + TWOPI);
    else
        return (angle);
#else
    return (angle);
#endif
}


//开平方根
double fsqrt(int n)
{

	double i=0,j=0;
	while(i*i<n){
		i++;//1 2 3
	}
	double left=i-1,right=i,mid;
	if(right*right==n){

		return right;
	}
	while(right-left>eps){
		mid=(left+right)/2;
		if(mid*mid>n){
			right=mid;
		}
		else{
			left=mid;
		}

	}

	return mid;
}


//用于测试逆解算法的函数
void Inverse_solution_algorithm(double x,double y,double z )
{





       float a, b;
   	float L1 = 10.5, L2 = 10, L3 = 12;
   	float m, n, t, q, p;
       float m1,m2,m3,m4,m5,m6;
       float n1,n2;
   	float j1, j2, j3, j0;
   	int   anle_con=15;
   	float  x1, y1, z1;
     // double x,y,z;
   	int o;
       float x2,y2,z2;
       int d,e,f,g;
    int i=0,j=0,state0=0,state1=0;





j0 = fast_atan2(y, x);
    n1 = sinus(j0);
    n2 = fcos(j0);
	a = x / n2;
	if (x == 0) a = y; //如果x为0，需要交换x，y
	b = z;

	for (j1 = 90; j1 > -90; j1--)
    //for (j1 = -90; j1 < 90; j1++)
	{
		j1 *= RAD2ANG;
        m1 = sinus(j1);
        m2 = fcos(j1);
		j3 = my_acos((kvat(a, 2) + kvat(b, 2) + kvat(L1, 2) - kvat(L2, 2) - kvat(L3, 2) - 2 * a*L1*m1 - 2 * b*L1*m2) / (2 * L2*L3));
        m3 = fcos(j3);
        m4 = sinus(j3);
		m = L2 * m1 + L3 * m1*m3 + L3 * m2*m4;
		n = L2 * m2 + L3 * m2*m3 - L3 * m1*m4;
		t = a - L1 * m1;
		p = fsqrt(kvat(n, 2) + kvat(m, 2));
		q = my_asin(m / p);
		j2 = -(my_asin(t / p) - q);
		m5 = sinus(j1 + j2);
        m6 = sinus(j1 + j2 + j3);
		x1 = (L1 * m1 + L2 * m5 + L3 * m6)*n2;
		y1 = (L1 * m1 + L2 * m5 + L3 * m6)*n1;
		z1 = L1 * m2 + L2 * fcos(j1 + j2) + L3 * fcos(j1 + j2 + j3);
		j1 = ANG2RAD(j1);
		j2 = ANG2RAD(j2);
		j3 = ANG2RAD(j3);
		if (x1<(x + 1) && x1 >(x - 1) && y1<(y + 1) && y1 >(y - 1) && z1<(z + 1) && z1 >(z - 1))
		{


			if(j3<135){
//printf("j0:%f,j1:%f,j2:%f,j3:%f,x:%f,y:%f,z:%f\r\n", ANG2RAD(j0), j1, j2, j3, x1, y1, z1);
if(ANG2RAD(j0)<0)
	anle_con=anle_con&0xE;
if(j1<0)
	anle_con=anle_con&0xD;
if(j2<0)
	anle_con=anle_con&0xB;
if(j3<0)
	anle_con=anle_con&0x7;

anl_con=anle_con;/*
uart_write(UART0,ANG2RAD(j0));
uart_write(UART0,j1);
uart_write(UART0,j2);
uart_write(UART0,j3);
*/
				ANLE_L0=ANG2RAD(j0);
				ANLE_L1=j1;
				ANLE_L2=j2;
				ANLE_L3=j3;



            }
		}
	}

}






