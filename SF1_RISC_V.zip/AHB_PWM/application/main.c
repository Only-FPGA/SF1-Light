#include <stdio.h>
#include "pwm.h"
#include "Inverse solution algorithm.h"

#include "../../../../SoC/anlogic/Board/sf1_eval/Include/nuclei_sdk_hal.h"



int main(void)
{key_leida();
	uint32_t dis;
	uint32_t REAL_dis_y;
	uint8_t rec_mes;
	uint32_t REAL_Y;
	uint32_t Y_FLAG;

	uart_init(UART0, 115200,UART_BIT_LENGTH_8);
	uart_clean_fifo(UART0);
	//接收图片信息
	rec_mes=uart_read(UART0);
//控制电机移动
		key_dianji_1=1;
		delay_1ms(20);
		key_dianji_1=0;
		delay_1ms(200);
		key_dianji_1=1;


//处理距离信息
delay_1ms(30000);
	dis=test;
	if(dis>=600)
		dis=500;
	else if(dis>=500&&dis<600)
		dis=dis-20;
	else if(dis>=400&&dis<500)
		dis=dis-20;
	else
		dis=dis+20;


test=dis;
		//采集来自FPGA的距离信息
		REAL_dis_y=realy_dis_y/10;
		Y_FLAG=regative_flag;
		//realy_dis_y=290;测试






uint32_t AA2;
uart_write(UART0,REAL_dis_y);
int   anle_con=15;
float a, b;
//准备逆解算法
		   	float L1 = 10.5, L2 = 10, L3 = 12;

		   	float m, n, t, q, p;
		       float m1,m2,m3,m4,m5,m6;
		       float n1,n2;
		   	float j1, j2, j3, j0;
		   	float  x1, y1, z1;
		      double x,y,z;
		   	int o;
		       float x2,y2,z2;
		       int d,e,f,g;
		    int i=0,j=0,state0=0,state1=0;
		    uart_init(UART0, 115200,UART_BIT_LENGTH_8);
		    uart_clean_fifo(UART0);


//逆解算法坐标
		x=0;
		y=REAL_dis_y-2;

		z=0;




		j0 = fast_atan2(y, x);
		    n1 = sinus(j0);
		    n2 = fcos(j0);
			a = x / n2;
			if (x == 0) a = y; //如果x为0，需要交换x，y
			b = z;

			for (j1 = 90; j1 > -90; j1--)
		    //for (j1 = -90; j1 < 90; j1++)
			{
				j1 *= RAD2ANG;
		        m1 = sinus(j1);
		        m2 = fcos(j1);
				j3 = my_acos((kvat(a, 2) + kvat(b, 2) + kvat(L1, 2) - kvat(L2, 2) - kvat(L3, 2) - 2 * a*L1*m1 - 2 * b*L1*m2) / (2 * L2*L3));
		        m3 = fcos(j3);
		        m4 = sinus(j3);
				m = L2 * m1 + L3 * m1*m3 + L3 * m2*m4;
				n = L2 * m2 + L3 * m2*m3 - L3 * m1*m4;
				t = a - L1 * m1;
				p = fsqrt(kvat(n, 2) + kvat(m, 2));
				q = my_asin(m / p);
				j2 = -(my_asin(t / p) - q);
				m5 = sinus(j1 + j2);
		        m6 = sinus(j1 + j2 + j3);
				x1 = (L1 * m1 + L2 * m5 + L3 * m6)*n2;
				y1 = (L1 * m1 + L2 * m5 + L3 * m6)*n1;
				z1 = L1 * m2 + L2 * fcos(j1 + j2) + L3 * fcos(j1 + j2 + j3);
				j1 = ANG2RAD(j1);
				j2 = ANG2RAD(j2);
				j3 = ANG2RAD(j3);
				if (x1<(x + 1) && x1 >(x - 1) && y1<(y + 1) && y1 >(y - 1) && z1<(z + 1) && z1 >(z - 1))
				{


					if(j3<135){




		    ANLE_L0=ANG2RAD(j0);
		    delay_1ms(1);
		    				ANLE_L1=j1;
		    				delay_1ms(1);
		    				//ANLE_L2=my_abs(j2);
		    				delay_1ms(1);
		    				ANLE_L3=j3;

		    				//XB_CON=1;

		    				if(ANG2RAD(j0)<0)

		    					anle_con=anle_con&0xE;
		    				if(j1<0)
		    					anle_con=anle_con&0xD;

		    				if(j2<0){
		    					anle_con=anle_con&0xB;

		    				}
		    				if(j3<0)
		    					anle_con=anle_con&0x7;
	 	    				JXB_CON=anle_con;
		    				uart_write(UART0,anle_con );
		    				  	  	  	  uart_write(UART0,ANG2RAD(j0)) ;
		    						    uart_write(UART0,j1) ;
		    						   // uart_write(UART0,my_abs(j2) );
		    						    ANLE_L2=my_abs(j2);//wxz
		    						    uart_write(UART0,my_abs(j2)) ;
		    						    uart_write(UART0,j3) ;
		    						    delay_1ms(10);
		    						    AA2=pwm_duty0;
		    						   uart_write(UART0,AA2);
		    						   uart_write(UART0,1);


		      break;

					}
				}
			}
}






















