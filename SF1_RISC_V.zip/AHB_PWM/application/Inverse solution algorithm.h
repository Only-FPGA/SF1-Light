/*
 * Inverse solution algorithm.h
 *
 *  Created on: 2022年10月26日
 *      Author: 86188
 */

#ifndef APPLICATION_INVERSE_SOLUTION_ALGORITHM_H_
#define APPLICATION_INVERSE_SOLUTION_ALGORITHM_H_

#define PI 3.1415926
#define eps 1e-7
#define RAD2ANG (3.1415926535898/180.0)
#define ANG2RAD(N) ( (N) * (180.0/3.1415926535898) )


#define TAN_MAP_RES     0.003921569f
#define RAD_PER_DEG     0.017453293f
#define TAN_MAP_SIZE    256


float fac(float n); //阶乘
float kvat(float n,float ci); //次方
float sinus(float x);
float fcos(float x);
float  my_acos(float x);
float  my_asin(float in);
float  my_abs(float f);
float fast_atan2(float y, float x);
void Inverse_solution_algorithm(double x,double y,double z );
double fsqrt(int n);



#define ARR_SIZE 4













#endif /* APPLICATION_INVERSE_SOLUTION_ALGORITHM_H_ */
