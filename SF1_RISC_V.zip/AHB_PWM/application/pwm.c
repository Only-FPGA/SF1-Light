


#include <stdio.h>
#include "pwm.h"


void key_leida(void){


	key_ld=1;
		delay_1ms(20);
		key_ld=0;
		delay_1ms(200);
		key_ld=1;

		delay_1ms(500);

		key_ld=1;
			delay_1ms(20);
			key_ld=0;
			delay_1ms(200);
			key_ld=1;

			delay_1ms(500);

			key_ld=1;
				delay_1ms(20);
				key_ld=0;
				delay_1ms(200);
				key_ld=1;

}
